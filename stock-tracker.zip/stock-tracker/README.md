# 📡 Stock Signal Tracker

## Sådan starter du (Windows, Mac eller Linux)

### Krav
- Node.js installeret: https://nodejs.org (vælg "LTS" versionen)

### Start appen
1. Pak zip-filen ud
2. Åbn Terminal (Mac/Linux) eller Command Prompt (Windows)
3. Naviger til mappen:
   cd stock-tracker
4. Installer afhængigheder (kun første gang):
   npm install
5. Start appen:
   npm start
6. Appen åbner automatisk i din browser på http://localhost:3000

## Funktioner
- 🔴 Live aktiekurser via Yahoo Finance
- 📐 Fibonacci retracement niveauer
- 📊 RSI-14 signal
- 📈 MACD signal
- 〰️ Moving Average signal
- 🔊 Lyd-alert når signaler krydser
- 📋 Signal log

## Aktier inkluderet
- 🚀 Moonshots: RCAT, ACHR, ERAS, SMR, SOUN, RGTI, CAN, MU, IONQ
- 📈 Long Term: MSFT, NVTS, PGY, TSM
- 💼 ETF Fonde: AGIX, QTUM, BAI, XBI, UFO
